import os
from flask import Flask, send_from_directory


#caminho base do projeto (uma pasta acima do backend)
BASE_DIR =os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

#pasta frontend (HTML e JS)
FRONTEND_DIR = os.path. join(BASE_DIR, "frontend")

STATIC_DIR = os.path.join(BASE_DIR,"static")

app = Flask(__name__)

@app.route("/")
def home():
    return "bom dia"

app.run()